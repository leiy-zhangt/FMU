/*
 * File: guidence_plane_types.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 29-Jul-2024 11:36:07
 */

#ifndef GUIDENCE_PLANE_TYPES_H
#define GUIDENCE_PLANE_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for guidence_plane_types.h
 *
 * [EOF]
 */
