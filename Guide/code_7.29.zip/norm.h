/*
 * File: norm.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 29-Jul-2024 11:36:07
 */

#ifndef NORM_H
#define NORM_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "guidence_plane_types.h"

/* Function Declarations */
extern double b_norm(const double x[3]);
extern double c_norm(const double x[2]);

#endif

/*
 * File trailer for norm.h
 *
 * [EOF]
 */
