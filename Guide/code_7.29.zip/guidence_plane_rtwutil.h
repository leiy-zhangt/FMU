/*
 * File: guidence_plane_rtwutil.h
 *
 * MATLAB Coder version            : 4.1
 * C/C++ source code generated on  : 29-Jul-2024 11:36:07
 */

#ifndef GUIDENCE_PLANE_RTWUTIL_H
#define GUIDENCE_PLANE_RTWUTIL_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "guidence_plane_types.h"

/* Function Declarations */
extern double rt_atan2d_snf(double u0, double u1);

#endif

/*
 * File trailer for guidence_plane_rtwutil.h
 *
 * [EOF]
 */
